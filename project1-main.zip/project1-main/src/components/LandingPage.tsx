import React from 'react';
import { UserRole } from '../types/medical';
import { Stethoscope, Pill, User, Shield, Zap, CheckCircle } from 'lucide-react';

interface LandingPageProps {
  onRoleSelect: (role: UserRole) => void;
}

export function LandingPage({ onRoleSelect }: LandingPageProps) {
  const roles = [
    {
      type: 'doctor' as UserRole,
      title: 'Doctor',
      description: 'Analyze prescriptions and check drug interactions with RxCUI mapping',
      icon: Stethoscope,
      color: 'bg-blue-600 hover:bg-blue-700',
      features: ['Drug interaction analysis', 'RxCUI mapping', 'Clinical decision support']
    },
    {
      type: 'pharmacist' as UserRole,
      title: 'Pharmacist',
      description: 'Verify dosage correctness and check age-appropriate alternatives',
      icon: Pill,
      color: 'bg-green-600 hover:bg-green-700',
      features: ['Dosage verification', 'Age-safe alternatives', 'Safety protocols']
    },
    {
      type: 'patient' as UserRole,
      title: 'Patient',
      description: 'Understand your prescriptions and potential interaction risks',
      icon: User,
      color: 'bg-purple-600 hover:bg-purple-700',
      features: ['Prescription insights', 'Risk understanding', 'Safety information']
    }
  ];

  const features = [
    {
      icon: Shield,
      title: 'AI-Powered Safety',
      description: 'Advanced NLP models analyze prescriptions for potential risks and interactions'
    },
    {
      icon: Zap,
      title: 'Real-time Analysis',
      description: 'Instant verification using RxNorm APIs and comprehensive drug databases'
    },
    {
      icon: CheckCircle,
      title: 'Evidence-Based',
      description: 'Recommendations based on clinical guidelines and pharmacological data'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-blue-600 to-green-600 p-2 rounded-lg">
                <Stethoscope className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900">MedSage</h1>
            </div>
            <div className="text-sm text-gray-600">
              AI-Powered Prescription Verification
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6 leading-tight">
            Intelligent Prescription
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-green-600"> Verification</span>
          </h2>
          <p className="text-xl text-gray-600 mb-12 max-w-3xl mx-auto leading-relaxed">
            Advanced AI system that analyzes drug interactions, verifies dosages, and suggests safe alternatives 
            based on patient-specific details. Enhancing safety for doctors, pharmacists, and patients.
          </p>

          {/* Feature Cards */}
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {features.map((feature, index) => (
              <div key={index} className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300">
                <div className="bg-gradient-to-r from-blue-100 to-green-100 p-3 rounded-lg w-fit mx-auto mb-4">
                  <feature.icon className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>

          <h3 className="text-2xl font-semibold text-gray-900 mb-8">Select Your Role</h3>
        </div>
      </section>

      {/* Role Selection */}
      <section className="pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            {roles.map((role, index) => (
              <div key={index} className="group">
                <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1">
                  <div className="p-8">
                    <div className="flex items-center justify-center mb-6">
                      <div className={`p-4 rounded-full ${role.color.replace('hover:', '')} bg-opacity-10`}>
                        <role.icon className={`h-8 w-8 ${role.color.split(' ')[0].replace('bg-', 'text-')}`} />
                      </div>
                    </div>
                    
                    <h3 className="text-2xl font-bold text-gray-900 mb-3 text-center">{role.title}</h3>
                    <p className="text-gray-600 mb-6 text-center leading-relaxed">{role.description}</p>
                    
                    <div className="space-y-2 mb-8">
                      {role.features.map((feature, featureIndex) => (
                        <div key={featureIndex} className="flex items-center space-x-2">
                          <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
                          <span className="text-sm text-gray-700">{feature}</span>
                        </div>
                      ))}
                    </div>
                    
                    <button
                      onClick={() => onRoleSelect(role.type)}
                      className={`w-full py-3 px-6 rounded-lg font-semibold text-white transition-all duration-200 ${role.color} transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-blue-200`}
                    >
                      Continue as {role.title}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-600">
            <p>© 2025 MedSage. Advanced AI-powered prescription verification system.</p>
            <p className="text-sm mt-2">Built with safety and accuracy in mind for healthcare professionals.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}