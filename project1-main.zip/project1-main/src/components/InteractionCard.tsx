import React from 'react';
import { DrugInteraction, UserRole } from '../types/medical';
import { AlertTriangle, Info, Zap, Skull } from 'lucide-react';

interface InteractionCardProps {
  interaction: DrugInteraction;
  role: UserRole;
}

export function InteractionCard({ interaction, role }: InteractionCardProps) {
  const getSeverityConfig = (severity: string) => {
    switch (severity) {
      case 'critical':
        return {
          color: 'border-red-500 bg-red-50',
          badge: 'bg-red-600 text-white',
          icon: Skull,
          iconColor: 'text-red-600'
        };
      case 'high':
        return {
          color: 'border-orange-500 bg-orange-50',
          badge: 'bg-orange-600 text-white',
          icon: AlertTriangle,
          iconColor: 'text-orange-600'
        };
      case 'moderate':
        return {
          color: 'border-amber-500 bg-amber-50',
          badge: 'bg-amber-600 text-white',
          icon: Zap,
          iconColor: 'text-amber-600'
        };
      default:
        return {
          color: 'border-yellow-500 bg-yellow-50',
          badge: 'bg-yellow-600 text-white',
          icon: Info,
          iconColor: 'text-yellow-600'
        };
    }
  };

  const config = getSeverityConfig(interaction.severity);
  const SeverityIcon = config.icon;

  const getRoleSpecificContent = () => {
    switch (role) {
      case 'doctor':
        return (
          <div className="text-sm text-gray-700">
            <p><strong>Clinical Consideration:</strong> Monitor patient for signs of interaction. Consider alternative therapy if clinically indicated.</p>
          </div>
        );
      case 'pharmacist':
        return (
          <div className="text-sm text-gray-700">
            <p><strong>Dispensing Note:</strong> Counsel patient on timing of administration and monitoring requirements.</p>
          </div>
        );
      case 'patient':
        return (
          <div className="text-sm text-gray-700">
            <p><strong>What this means:</strong> These medications may affect each other. Follow your doctor's instructions carefully and report any unusual symptoms.</p>
          </div>
        );
    }
  };

  return (
    <div className={`border-2 rounded-lg p-6 ${config.color} hover:shadow-md transition-all duration-200`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <SeverityIcon className={`h-6 w-6 ${config.iconColor}`} />
          <div>
            <h4 className="font-semibold text-gray-900">
              {interaction.drug1} + {interaction.drug2}
            </h4>
            <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${config.badge} mt-1`}>
              {interaction.severity.toUpperCase()} INTERACTION
            </span>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <p className="text-gray-800 font-medium mb-2">Interaction Description:</p>
          <p className="text-gray-700 text-sm leading-relaxed">{interaction.description}</p>
        </div>

        <div>
          <p className="text-gray-800 font-medium mb-2">Mechanism:</p>
          <p className="text-gray-700 text-sm leading-relaxed">{interaction.mechanism}</p>
        </div>

        <div>
          <p className="text-gray-800 font-medium mb-2">Recommendations:</p>
          <ul className="space-y-1">
            {interaction.recommendations.map((rec, index) => (
              <li key={index} className="flex items-start space-x-2 text-sm text-gray-700">
                <span className="text-blue-600 font-bold">•</span>
                <span>{rec}</span>
              </li>
            ))}
          </ul>
        </div>

        {getRoleSpecificContent()}
      </div>
    </div>
  );
}