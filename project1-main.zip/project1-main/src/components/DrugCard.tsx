import React from 'react';
import { Drug } from '../types/medical';
import { Pill, Hash, Clock } from 'lucide-react';

interface DrugCardProps {
  drug: Drug;
}

export function DrugCard({ drug }: DrugCardProps) {
  return (
    <div className="bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-4 hover:shadow-md transition-all duration-200">
      <div className="flex items-start space-x-3">
        <div className="bg-blue-100 p-2 rounded-lg flex-shrink-0">
          <Pill className="h-4 w-4 text-blue-600" />
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="font-semibold text-gray-900 truncate">{drug.name}</h4>
          {drug.genericName && drug.genericName !== drug.name && (
            <p className="text-xs text-gray-500 mt-1">Generic: {drug.genericName}</p>
          )}
          
          <div className="mt-3 space-y-2">
            <div className="flex items-center space-x-2 text-sm">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-gray-700">{drug.dosage}</span>
            </div>
            
            <div className="flex items-center space-x-2 text-sm">
              <Clock className="h-3 w-3 text-gray-500" />
              <span className="text-gray-600">{drug.frequency}</span>
            </div>
            
            {drug.rxcui && (
              <div className="flex items-center space-x-2 text-xs">
                <Hash className="h-3 w-3 text-gray-400" />
                <span className="text-gray-500">RxCUI: {drug.rxcui}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}