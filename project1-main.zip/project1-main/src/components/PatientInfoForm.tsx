import React, { useState } from 'react';
import { PatientInfo } from '../types/medical';
import { User, ArrowLeft, Plus, X } from 'lucide-react';

interface PatientInfoFormProps {
  onSubmit: (info: PatientInfo) => void;
  onBack: () => void;
}

export function PatientInfoForm({ onSubmit, onBack }: PatientInfoFormProps) {
  const [patientInfo, setPatientInfo] = useState<PatientInfo>({
    age: 35,
    weight: 70,
    allergies: [],
    medicalConditions: [],
    currentMedications: []
  });

  const [newAllergy, setNewAllergy] = useState('');
  const [newCondition, setNewCondition] = useState('');
  const [newMedication, setNewMedication] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(patientInfo);
  };

  const addItem = (type: 'allergies' | 'medicalConditions' | 'currentMedications', value: string) => {
    if (value.trim()) {
      setPatientInfo(prev => ({
        ...prev,
        [type]: [...prev[type], value.trim()]
      }));
      
      if (type === 'allergies') setNewAllergy('');
      if (type === 'medicalConditions') setNewCondition('');
      if (type === 'currentMedications') setNewMedication('');
    }
  };

  const removeItem = (type: 'allergies' | 'medicalConditions' | 'currentMedications', index: number) => {
    setPatientInfo(prev => ({
      ...prev,
      [type]: prev[type].filter((_, i) => i !== index)
    }));
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-50 to-blue-50 px-8 py-6 border-b border-gray-200">
          <div className="flex items-center space-x-3 mb-2">
            <User className="h-6 w-6 text-purple-600" />
            <h2 className="text-2xl font-bold text-gray-900">Patient Information</h2>
          </div>
          <p className="text-gray-600">
            Provide patient details for personalized safety analysis and age-appropriate recommendations
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-8">
          <div className="grid md:grid-cols-2 gap-8">
            {/* Basic Info */}
            <div className="space-y-6">
              <h3 className="text-lg font-semibold text-gray-900">Basic Information</h3>
              
              <div>
                <label htmlFor="age" className="block text-sm font-medium text-gray-700 mb-2">
                  Age (years) *
                </label>
                <input
                  type="number"
                  id="age"
                  value={patientInfo.age}
                  onChange={(e) => setPatientInfo(prev => ({ ...prev, age: parseInt(e.target.value) || 0 }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  required
                  min="1"
                  max="120"
                />
              </div>

              <div>
                <label htmlFor="weight" className="block text-sm font-medium text-gray-700 mb-2">
                  Weight (kg)
                </label>
                <input
                  type="number"
                  id="weight"
                  value={patientInfo.weight || ''}
                  onChange={(e) => setPatientInfo(prev => ({ ...prev, weight: parseInt(e.target.value) || undefined }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  min="1"
                  max="300"
                />
              </div>
            </div>

            {/* Medical History */}
            <div className="space-y-6">
              <h3 className="text-lg font-semibold text-gray-900">Medical History</h3>
              
              {/* Allergies */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Allergies</label>
                <div className="flex space-x-2 mb-2">
                  <input
                    type="text"
                    value={newAllergy}
                    onChange={(e) => setNewAllergy(e.target.value)}
                    placeholder="Enter allergy (e.g., Penicillin)"
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addItem('allergies', newAllergy))}
                  />
                  <button
                    type="button"
                    onClick={() => addItem('allergies', newAllergy)}
                    className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg transition-colors"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {patientInfo.allergies.map((allergy, index) => (
                    <span key={index} className="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm flex items-center space-x-1">
                      <span>{allergy}</span>
                      <button
                        type="button"
                        onClick={() => removeItem('allergies', index)}
                        className="hover:bg-red-200 rounded-full p-0.5"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              {/* Medical Conditions */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Medical Conditions</label>
                <div className="flex space-x-2 mb-2">
                  <input
                    type="text"
                    value={newCondition}
                    onChange={(e) => setNewCondition(e.target.value)}
                    placeholder="Enter condition (e.g., Diabetes)"
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addItem('medicalConditions', newCondition))}
                  />
                  <button
                    type="button"
                    onClick={() => addItem('medicalConditions', newCondition)}
                    className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg transition-colors"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {patientInfo.medicalConditions.map((condition, index) => (
                    <span key={index} className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm flex items-center space-x-1">
                      <span>{condition}</span>
                      <button
                        type="button"
                        onClick={() => removeItem('medicalConditions', index)}
                        className="hover:bg-blue-200 rounded-full p-0.5"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              {/* Current Medications */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Current Medications</label>
                <div className="flex space-x-2 mb-2">
                  <input
                    type="text"
                    value={newMedication}
                    onChange={(e) => setNewMedication(e.target.value)}
                    placeholder="Enter medication (e.g., Aspirin 81mg daily)"
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addItem('currentMedications', newMedication))}
                  />
                  <button
                    type="button"
                    onClick={() => addItem('currentMedications', newMedication)}
                    className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg transition-colors"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {patientInfo.currentMedications.map((medication, index) => (
                    <span key={index} className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm flex items-center space-x-1">
                      <span>{medication}</span>
                      <button
                        type="button"
                        onClick={() => removeItem('currentMedications', index)}
                        className="hover:bg-green-200 rounded-full p-0.5"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-between items-center mt-8 pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={onBack}
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Back to Prescription</span>
            </button>

            <button
              type="submit"
              className="bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-200 transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-purple-200"
            >
              Continue Analysis
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}