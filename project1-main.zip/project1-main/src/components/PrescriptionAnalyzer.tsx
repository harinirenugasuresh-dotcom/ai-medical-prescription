import React, { useState } from 'react';
import { UserRole, AnalysisResult, PatientInfo } from '../types/medical';
import { ArrowLeft, Loader2, Upload, FileText } from 'lucide-react';
import { PrescriptionInput } from './PrescriptionInput';
import { PatientInfoForm } from './PatientInfoForm';
import { AnalysisResults } from './AnalysisResults';
import { mockAnalysis } from '../utils/mockData';

interface PrescriptionAnalyzerProps {
  role: UserRole;
  onBack: () => void;
}

export function PrescriptionAnalyzer({ role, onBack }: PrescriptionAnalyzerProps) {
  const [prescriptionText, setPrescriptionText] = useState('');
  const [patientInfo, setPatientInfo] = useState<PatientInfo>({
    age: 35,
    weight: 70,
    allergies: [],
    medicalConditions: [],
    currentMedications: []
  });
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [step, setStep] = useState<'input' | 'patient-info' | 'results'>('input');

  const handlePrescriptionSubmit = (text: string) => {
    setPrescriptionText(text);
    if (role === 'patient') {
      setStep('patient-info');
    } else {
      analyzeRescription(text, patientInfo);
    }
  };

  const handlePatientInfoSubmit = (info: PatientInfo) => {
    setPatientInfo(info);
    analyzeRescription(prescriptionText, info);
  };

  const analyzeRescription = async (text: string, info: PatientInfo) => {
    setIsAnalyzing(true);
    setStep('results');
    
    // Simulate AI analysis with realistic delay
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const result = mockAnalysis(text, info, role);
    setAnalysisResult(result);
    setIsAnalyzing(false);
  };

  const handleNewAnalysis = () => {
    setStep('input');
    setAnalysisResult(null);
    setPrescriptionText('');
  };

  const getRoleTitle = () => {
    switch (role) {
      case 'doctor': return 'Clinical Decision Support';
      case 'pharmacist': return 'Pharmacy Verification System';
      case 'patient': return 'Prescription Safety Checker';
    }
  };

  const getRoleDescription = () => {
    switch (role) {
      case 'doctor': return 'Analyze prescriptions for drug interactions and clinical safety';
      case 'pharmacist': return 'Verify dosages and check for age-appropriate alternatives';
      case 'patient': return 'Understand your prescriptions and potential safety concerns';
    }
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
              >
                <ArrowLeft className="h-5 w-5" />
                <span>Back</span>
              </button>
              <div className="flex items-center space-x-3">
                <div className="bg-gradient-to-r from-blue-600 to-green-600 p-2 rounded-lg">
                  <FileText className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">{getRoleTitle()}</h1>
                  <p className="text-sm text-gray-600">{getRoleDescription()}</p>
                </div>
              </div>
            </div>
            <div className="text-sm text-gray-500 capitalize">{role} Portal</div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {step === 'input' && (
          <PrescriptionInput
            role={role}
            onSubmit={handlePrescriptionSubmit}
          />
        )}

        {step === 'patient-info' && (
          <PatientInfoForm
            onSubmit={handlePatientInfoSubmit}
            onBack={() => setStep('input')}
          />
        )}

        {step === 'results' && (
          <div>
            {isAnalyzing ? (
              <div className="bg-white rounded-xl shadow-lg p-12 text-center">
                <div className="flex flex-col items-center space-y-4">
                  <div className="relative">
                    <Loader2 className="h-12 w-12 text-blue-600 animate-spin" />
                    <div className="absolute inset-0 bg-blue-100 rounded-full animate-pulse opacity-20"></div>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900">Analyzing Prescription</h3>
                  <div className="space-y-2 text-gray-600">
                    <p>• Extracting drug names and dosages using medical NER</p>
                    <p>• Cross-referencing with RxNorm database</p>
                    <p>• Checking drug-drug interactions</p>
                    <p>• Verifying age-appropriate dosages</p>
                    <p>• Generating safety recommendations</p>
                  </div>
                </div>
              </div>
            ) : analysisResult ? (
              <AnalysisResults
                result={analysisResult}
                role={role}
                patientInfo={patientInfo}
                onNewAnalysis={handleNewAnalysis}
              />
            ) : null}
          </div>
        )}
      </main>
    </div>
  );
}