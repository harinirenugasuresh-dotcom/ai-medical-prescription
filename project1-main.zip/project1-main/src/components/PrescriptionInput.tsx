import React, { useState } from 'react';
import { UserRole } from '../types/medical';
import { Upload, FileText, Zap, AlertTriangle } from 'lucide-react';

interface PrescriptionInputProps {
  role: UserRole;
  onSubmit: (text: string) => void;
}

export function PrescriptionInput({ role, onSubmit }: PrescriptionInputProps) {
  const [inputText, setInputText] = useState('');
  const [inputMethod, setInputMethod] = useState<'text' | 'upload'>('text');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputText.trim()) {
      onSubmit(inputText.trim());
    }
  };

  const handleSampleLoad = () => {
    const samplePrescriptions = {
      doctor: 'Rx: Metformin 500mg twice daily, Lisinopril 10mg once daily, Atorvastatin 20mg at bedtime. Patient: 55-year-old male with Type 2 diabetes and hypertension.',
      pharmacist: 'Amoxicillin 875mg BID x 10 days, Warfarin 5mg daily, Patient age: 72 years. Verify dosing and check for interactions.',
      patient: 'My doctor prescribed: Ibuprofen 600mg every 6 hours as needed for pain, Omeprazole 20mg daily before breakfast. I\'m 28 years old and currently taking birth control pills.'
    };
    
    setInputText(samplePrescriptions[role]);
  };

  const getPlaceholder = () => {
    switch (role) {
      case 'doctor':
        return 'Enter prescription details (e.g., "Metformin 500mg BID, Lisinopril 10mg daily for 55-year-old male patient...")';
      case 'pharmacist':
        return 'Enter prescription for verification (e.g., "Amoxicillin 875mg BID x 10 days, patient age 72...")';
      case 'patient':
        return 'Describe your prescriptions (e.g., "My doctor prescribed ibuprofen 600mg every 6 hours...")';
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-50 to-green-50 px-8 py-6 border-b border-gray-200">
          <div className="flex items-center space-x-3 mb-2">
            <FileText className="h-6 w-6 text-blue-600" />
            <h2 className="text-2xl font-bold text-gray-900">Prescription Analysis</h2>
          </div>
          <p className="text-gray-600">
            Enter prescription details to analyze drug interactions, verify dosages, and get safety recommendations
          </p>
        </div>

        {/* Input Method Toggle */}
        <div className="px-8 py-4 border-b border-gray-100">
          <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg w-fit">
            <button
              onClick={() => setInputMethod('text')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                inputMethod === 'text'
                  ? 'bg-white text-blue-600 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <FileText className="h-4 w-4 inline mr-2" />
              Text Input
            </button>
            <button
              onClick={() => setInputMethod('upload')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                inputMethod === 'upload'
                  ? 'bg-white text-blue-600 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Upload className="h-4 w-4 inline mr-2" />
              Upload File
            </button>
          </div>
        </div>

        {/* Input Form */}
        <form onSubmit={handleSubmit} className="p-8">
          {inputMethod === 'text' ? (
            <div className="space-y-6">
              <div>
                <label htmlFor="prescription" className="block text-sm font-medium text-gray-900 mb-2">
                  Prescription Details
                </label>
                <textarea
                  id="prescription"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder={getPlaceholder()}
                  rows={8}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none transition-all"
                  required
                />
              </div>

              <div className="flex justify-between items-center">
                <button
                  type="button"
                  onClick={handleSampleLoad}
                  className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 transition-colors"
                >
                  <Zap className="h-4 w-4" />
                  <span>Load Sample Prescription</span>
                </button>

                <button
                  type="submit"
                  disabled={!inputText.trim()}
                  className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 disabled:from-gray-400 disabled:to-gray-500 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-200 transform hover:scale-105 disabled:transform-none disabled:cursor-not-allowed focus:outline-none focus:ring-4 focus:ring-blue-200"
                >
                  Analyze Prescription
                </button>
              </div>
            </div>
          ) : (
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center hover:border-blue-400 transition-colors">
              <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Upload Prescription</h3>
              <p className="text-gray-600 mb-4">
                Upload a prescription image or PDF for AI-powered text extraction
              </p>
              <button
                type="button"
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-medium transition-colors"
              >
                Choose File
              </button>
              <p className="text-xs text-gray-500 mt-2">Supports JPG, PNG, PDF up to 10MB</p>
            </div>
          )}

          {/* Safety Notice */}
          <div className="mt-6 bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-start space-x-3">
            <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm text-amber-800">
                <strong>Medical Disclaimer:</strong> This system provides analytical insights for educational and 
                decision-support purposes only. Always consult with healthcare professionals for medical decisions.
              </p>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}