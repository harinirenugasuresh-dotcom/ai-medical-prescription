import React from 'react';
import { AnalysisResult, UserRole, PatientInfo } from '../types/medical';
import { Shield, AlertTriangle, CheckCircle, Pill, RotateCcw, Download, Share } from 'lucide-react';
import { InteractionCard } from './InteractionCard';
import { DosageCard } from './DosageCard';
import { AlternativeCard } from './AlternativeCard';
import { DrugCard } from './DrugCard';

interface AnalysisResultsProps {
  result: AnalysisResult;
  role: UserRole;
  patientInfo: PatientInfo;
  onNewAnalysis: () => void;
}

export function AnalysisResults({ result, role, patientInfo, onNewAnalysis }: AnalysisResultsProps) {
  const getRiskColor = (score: number) => {
    if (score >= 80) return 'text-red-600 bg-red-50 border-red-200';
    if (score >= 60) return 'text-amber-600 bg-amber-50 border-amber-200';
    if (score >= 30) return 'text-yellow-600 bg-yellow-50 border-yellow-200';
    return 'text-green-600 bg-green-50 border-green-200';
  };

  const getRiskLabel = (score: number) => {
    if (score >= 80) return 'High Risk';
    if (score >= 60) return 'Moderate Risk';
    if (score >= 30) return 'Low Risk';
    return 'Minimal Risk';
  };

  const getRiskIcon = (score: number) => {
    if (score >= 60) return AlertTriangle;
    if (score >= 30) return Shield;
    return CheckCircle;
  };

  const RiskIcon = getRiskIcon(result.overallRiskScore);

  return (
    <div className="space-y-8">
      {/* Header with Risk Score */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="bg-gradient-to-r from-blue-50 to-green-50 px-8 py-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Analysis Complete</h2>
              <p className="text-gray-600">Comprehensive prescription safety analysis for {patientInfo.age}-year-old patient</p>
            </div>
            <div className={`flex items-center space-x-3 px-6 py-3 rounded-lg border-2 ${getRiskColor(result.overallRiskScore)}`}>
              <RiskIcon className="h-6 w-6" />
              <div>
                <div className="font-semibold">{getRiskLabel(result.overallRiskScore)}</div>
                <div className="text-sm opacity-75">Score: {result.overallRiskScore}/100</div>
              </div>
            </div>
          </div>
        </div>

        <div className="p-8">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Executive Summary</h3>
              <p className="text-gray-700 leading-relaxed">{result.summary}</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Key Recommendations</h3>
              <ul className="space-y-2">
                {result.recommendations.map((rec, index) => (
                  <li key={index} className="flex items-start space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700 text-sm">{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Extracted Drugs */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="px-8 py-6 border-b border-gray-200">
          <h3 className="text-xl font-bold text-gray-900 flex items-center space-x-2">
            <Pill className="h-6 w-6 text-blue-600" />
            <span>Extracted Medications ({result.extractedDrugs.length})</span>
          </h3>
        </div>
        <div className="p-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {result.extractedDrugs.map((drug, index) => (
              <DrugCard key={index} drug={drug} />
            ))}
          </div>
        </div>
      </div>

      {/* Drug Interactions */}
      {result.interactions.length > 0 && (
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="px-8 py-6 border-b border-gray-200">
            <h3 className="text-xl font-bold text-gray-900 flex items-center space-x-2">
              <AlertTriangle className="h-6 w-6 text-amber-600" />
              <span>Drug Interactions ({result.interactions.length})</span>
            </h3>
          </div>
          <div className="p-8 space-y-4">
            {result.interactions.map((interaction, index) => (
              <InteractionCard key={index} interaction={interaction} role={role} />
            ))}
          </div>
        </div>
      )}

      {/* Dosage Verifications */}
      {result.dosageVerifications.length > 0 && (
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="px-8 py-6 border-b border-gray-200">
            <h3 className="text-xl font-bold text-gray-900 flex items-center space-x-2">
              <Shield className="h-6 w-6 text-green-600" />
              <span>Dosage Verification ({result.dosageVerifications.length})</span>
            </h3>
          </div>
          <div className="p-8 space-y-4">
            {result.dosageVerifications.map((verification, index) => (
              <DosageCard key={index} verification={verification} role={role} />
            ))}
          </div>
        </div>
      )}

      {/* Alternative Medications */}
      {result.alternatives.length > 0 && (
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="px-8 py-6 border-b border-gray-200">
            <h3 className="text-xl font-bold text-gray-900 flex items-center space-x-2">
              <Pill className="h-6 w-6 text-purple-600" />
              <span>Alternative Medications ({result.alternatives.length})</span>
            </h3>
          </div>
          <div className="p-8 space-y-4">
            {result.alternatives.map((alternative, index) => (
              <AlternativeCard key={index} alternative={alternative} role={role} />
            ))}
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="bg-white rounded-xl shadow-lg p-8">
        <div className="flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0 sm:space-x-4">
          <button
            onClick={onNewAnalysis}
            className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-200 transform hover:scale-105"
          >
            <RotateCcw className="h-4 w-4" />
            <span>New Analysis</span>
          </button>
          
          <div className="flex space-x-3">
            <button className="flex items-center space-x-2 bg-gray-600 hover:bg-gray-700 text-white px-4 py-3 rounded-lg font-medium transition-colors">
              <Download className="h-4 w-4" />
              <span>Export Report</span>
            </button>
            
            {role !== 'patient' && (
              <button className="flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white px-4 py-3 rounded-lg font-medium transition-colors">
                <Share className="h-4 w-4" />
                <span>Share with Patient</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}