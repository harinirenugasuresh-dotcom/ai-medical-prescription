import React from 'react';
import { AlternativeMedication, UserRole } from '../types/medical';
import { ArrowRight, Star, CheckCircle } from 'lucide-react';

interface AlternativeCardProps {
  alternative: AlternativeMedication;
  role: UserRole;
}

export function AlternativeCard({ alternative, role }: AlternativeCardProps) {
  return (
    <div className="border-2 border-purple-200 bg-purple-50 rounded-lg p-6 hover:shadow-md transition-all duration-200">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="bg-purple-100 p-2 rounded-lg">
            <Star className="h-5 w-5 text-purple-600" />
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">Alternative Recommendation</h4>
            <p className="text-sm text-gray-600">{alternative.reason}</p>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="flex items-center space-x-4 bg-white p-4 rounded-lg border">
            <div>
              <p className="text-gray-700 font-medium">Original:</p>
              <p className="text-gray-900 font-semibold">{alternative.originalDrug}</p>
            </div>
            <ArrowRight className="h-5 w-5 text-gray-400" />
            <div>
              <p className="text-gray-700 font-medium">Alternative:</p>
              <p className="text-purple-600 font-semibold">{alternative.alternative}</p>
            </div>
          </div>

          <div>
            <p className="text-gray-700 font-medium mb-2">Brand Names Available:</p>
            <div className="flex flex-wrap gap-2">
              {alternative.brandNames.map((brand, index) => (
                <span key={index} className="bg-purple-100 text-purple-800 px-2 py-1 rounded text-xs font-medium">
                  {brand}
                </span>
              ))}
            </div>
          </div>

          <div>
            <p className="text-gray-700 font-medium mb-1">Equivalent Dosage:</p>
            <p className="text-gray-900 font-mono text-sm bg-white px-3 py-2 rounded border">
              {alternative.equivalentDosage}
            </p>
          </div>
        </div>

        <div>
          <p className="text-gray-700 font-medium mb-3">Benefits of Alternative:</p>
          <ul className="space-y-2">
            {alternative.benefits.map((benefit, index) => (
              <li key={index} className="flex items-start space-x-2 text-sm">
                <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span className="text-gray-700">{benefit}</span>
              </li>
            ))}
          </ul>

          {role === 'pharmacist' && (
            <div className="mt-4 p-3 bg-white rounded border">
              <p className="text-xs text-gray-600">
                <strong>Pharmacist Note:</strong> Verify insurance coverage and patient preference before substitution.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}