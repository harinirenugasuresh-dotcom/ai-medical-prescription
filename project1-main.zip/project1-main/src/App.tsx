import React, { useState } from 'react';
import { LandingPage } from './components/LandingPage';
import { PrescriptionAnalyzer } from './components/PrescriptionAnalyzer';
import { UserRole } from './types/medical';

function App() {
  const [currentRole, setCurrentRole] = useState<UserRole | null>(null);

  const handleRoleSelect = (role: UserRole) => {
    setCurrentRole(role);
  };

  const handleBackToLanding = () => {
    setCurrentRole(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      {!currentRole ? (
        <LandingPage onRoleSelect={handleRoleSelect} />
      ) : (
        <PrescriptionAnalyzer role={currentRole} onBack={handleBackToLanding} />
      )}
    </div>
  );
}

export default App;