export type UserRole = 'doctor' | 'pharmacist' | 'patient';

export type InteractionSeverity = 'low' | 'moderate' | 'high' | 'critical';

export interface Drug {
  name: string;
  dosage: string;
  frequency: string;
  rxcui?: string;
  genericName?: string;
}

export interface DrugInteraction {
  drug1: string;
  drug2: string;
  severity: InteractionSeverity;
  description: string;
  mechanism: string;
  recommendations: string[];
}

export interface DosageVerification {
  drug: string;
  prescribedDose: string;
  recommendedDose: string;
  ageGroup: string;
  isAppropriate: boolean;
  warnings: string[];
  adjustmentRecommendations?: string[];
}

export interface AlternativeMedication {
  originalDrug: string;
  alternative: string;
  brandNames: string[];
  reason: string;
  equivalentDosage: string;
  benefits: string[];
}

export interface AnalysisResult {
  extractedDrugs: Drug[];
  interactions: DrugInteraction[];
  dosageVerifications: DosageVerification[];
  alternatives: AlternativeMedication[];
  overallRiskScore: number;
  summary: string;
  recommendations: string[];
}

export interface PatientInfo {
  age: number;
  weight?: number;
  allergies: string[];
  medicalConditions: string[];
  currentMedications: string[];
}