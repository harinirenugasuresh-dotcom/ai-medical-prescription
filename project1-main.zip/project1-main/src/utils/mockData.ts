import { AnalysisResult, PatientInfo, UserRole, Drug, DrugInteraction, DosageVerification, AlternativeMedication } from '../types/medical';

export function mockAnalysis(prescriptionText: string, patientInfo: PatientInfo, role: UserRole): AnalysisResult {
  // Mock extracted drugs based on common prescription patterns
  const extractedDrugs: Drug[] = [
    {
      name: 'Metformin',
      dosage: '500mg',
      frequency: 'Twice daily',
      rxcui: 'RX860975',
      genericName: 'Metformin Hydrochloride'
    },
    {
      name: 'Lisinopril',
      dosage: '10mg',
      frequency: 'Once daily',
      rxcui: 'RX29046',
      genericName: 'Lisinopril'
    },
    {
      name: 'Atorvastatin',
      dosage: '20mg',
      frequency: 'At bedtime',
      rxcui: 'RX83367',
      genericName: 'Atorvastatin Calcium'
    }
  ];

  // Mock drug interactions
  const interactions: DrugInteraction[] = [
    {
      drug1: 'Metformin',
      drug2: 'Lisinopril',
      severity: 'moderate',
      description: 'ACE inhibitors may enhance the hypoglycemic effect of metformin, particularly in patients with renal impairment.',
      mechanism: 'ACE inhibitors can improve insulin sensitivity and glucose utilization, potentially amplifying metformin\'s glucose-lowering effects.',
      recommendations: [
        'Monitor blood glucose levels more frequently during initial combination therapy',
        'Watch for signs of hypoglycemia, especially in elderly patients',
        'Consider dose adjustment if blood glucose drops significantly',
        'Assess renal function regularly as both drugs can be affected by kidney function'
      ]
    }
  ];

  // Mock dosage verifications based on patient age
  const dosageVerifications: DosageVerification[] = [
    {
      drug: 'Metformin',
      prescribedDose: '500mg twice daily',
      recommendedDose: '500-850mg twice daily',
      ageGroup: 'Adult (18-65 years)',
      isAppropriate: true,
      warnings: ['Take with meals to reduce GI upset', 'Monitor for lactic acidosis symptoms']
    },
    {
      drug: 'Atorvastatin',
      prescribedDose: '20mg at bedtime',
      recommendedDose: '10-80mg daily',
      ageGroup: 'Adult (18-65 years)',
      isAppropriate: patientInfo.age < 65,
      warnings: patientInfo.age >= 65 ? ['Consider lower starting dose in elderly patients', 'Monitor for muscle-related side effects'] : ['Monitor liver function', 'Report muscle pain or weakness'],
      adjustmentRecommendations: patientInfo.age >= 65 ? ['Consider starting with 10mg daily', 'Titrate based on response and tolerance'] : undefined
    }
  ];

  // Mock alternative medications
  const alternatives: AlternativeMedication[] = [
    {
      originalDrug: 'Atorvastatin',
      alternative: 'Rosuvastatin',
      brandNames: ['Crestor', 'Ezallor'],
      reason: 'Lower interaction potential and better efficacy at lower doses',
      equivalentDosage: '10mg daily (equivalent to 20mg atorvastatin)',
      benefits: [
        'Reduced drug-drug interaction potential',
        'More potent LDL reduction at lower doses',
        'Less affected by genetic variations in metabolism',
        'Better cardiovascular outcomes in clinical trials'
      ]
    }
  ];

  // Calculate risk score based on interactions and patient factors
  let riskScore = 15; // Base score
  
  interactions.forEach(interaction => {
    switch (interaction.severity) {
      case 'critical': riskScore += 40; break;
      case 'high': riskScore += 25; break;
      case 'moderate': riskScore += 15; break;
      case 'low': riskScore += 5; break;
    }
  });

  // Age-based risk adjustment
  if (patientInfo.age >= 65) riskScore += 10;
  if (patientInfo.age >= 80) riskScore += 15;

  // Allergy-based risk
  riskScore += patientInfo.allergies.length * 5;

  // Cap at 100
  riskScore = Math.min(riskScore, 100);

  const generateSummary = () => {
    const drugCount = extractedDrugs.length;
    const interactionCount = interactions.length;
    const ageGroup = patientInfo.age >= 65 ? 'elderly' : patientInfo.age >= 18 ? 'adult' : 'pediatric';
    
    if (riskScore >= 80) {
      return `High-risk prescription identified for ${ageGroup} patient. ${drugCount} medications extracted with ${interactionCount} significant interaction(s). Immediate clinical review recommended.`;
    } else if (riskScore >= 60) {
      return `Moderate-risk prescription for ${ageGroup} patient. ${drugCount} medications with ${interactionCount} interaction(s) requiring monitoring. Consider dose adjustments.`;
    } else if (riskScore >= 30) {
      return `Low-risk prescription for ${ageGroup} patient. ${drugCount} medications identified with minor concerns. Routine monitoring recommended.`;
    } else {
      return `Low-risk prescription for ${ageGroup} patient. ${drugCount} medications with minimal safety concerns. Standard monitoring protocols apply.`;
    }
  };

  const generateRecommendations = () => {
    const recommendations = [];
    
    if (interactions.length > 0) {
      recommendations.push('Monitor for drug interaction symptoms as outlined above');
    }
    
    if (patientInfo.age >= 65) {
      recommendations.push('Consider geriatric dosing guidelines and increased monitoring frequency');
    }
    
    if (patientInfo.allergies.length > 0) {
      recommendations.push(`Verify no cross-reactivity with known allergies: ${patientInfo.allergies.join(', ')}`);
    }
    
    recommendations.push('Schedule follow-up appointment to assess therapy response');
    recommendations.push('Provide patient education on proper administration and side effects');
    
    if (role === 'pharmacist') {
      recommendations.push('Counsel patient on drug timing and food interactions');
    }
    
    return recommendations;
  };

  return {
    extractedDrugs,
    interactions,
    dosageVerifications,
    alternatives,
    overallRiskScore: riskScore,
    summary: generateSummary(),
    recommendations: generateRecommendations()
  };
}